package com.example.cungu.game2048;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.GridLayout;

public class GameView extends GridLayout{
    private Card[][] cardsMap = new Card[4][4];
    private List<Point> emptyPoints = new ArrayList<Point>();//定义一个集合来存放card的值为0的card的位置
    //三个构造方法
	public GameView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
		initGameView();
	}
	public GameView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		initGameView();
	}
	public GameView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		initGameView();
	}
	// 初始化方法
    private void initGameView(){
    	setColumnCount(4);
    	setBackgroundColor(this.getResources().getColor(R.color.BackgroundColor));
    	//重写触摸事件
    	setOnTouchListener(new OnTouchListener() {
    		private float startX,startY,offsetX,offsetY;//手指触碰和手指离开
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
			    switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					startX = event.getX();
					startY = event.getY();
					break;
				case MotionEvent.ACTION_UP:
					offsetX = event.getX()-startX;// 大于0则代表向右滑
					offsetY = event.getY()-startY;// 小于0代表向上滑
					
					//在水平方向上移动
					if(Math.abs(offsetX)>Math.abs(offsetY)){
						//向左滑动
						if(offsetX<-5){
							swipeLeft();
						//向右滑动
						}else if(offsetX>5){
							swipeRight();
						}
					}else{
						//向上滑动
						if(offsetY<-5){
							swipeUp();
						//向下滑动
						}else if(offsetY>5){
							swipeDown();
						}
					}
					break;
				default:
					break;
				}
				return true;
			}
		});
    }
    
    @Override
    //只在屏幕在创建的时候被执行
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    	// TODO Auto-generated method stub
    	super.onSizeChanged(w, h, oldw, oldh);
    	//对宽、高求最小值，然后求出每一张卡片的宽度
    	int cardWidth = (Math.min(w,h)-10)/4;
    	addCards(cardWidth, cardWidth);
    	startGame();
    }
    private void addCards(int cardWidth,int cardHeight){
    	Card c;
    	for(int y=0;y<4;y++){
    		for(int x=0;x<4;x++){
    			c = new Card(getContext());
    			c.setNum(0);
    			c.setBGColor(c.getNum());
    			addView(c, cardWidth, cardHeight);
    			cardsMap[x][y] = c;
    		}
    	}
    }
    public void startGame(){
    	MainActivity.getMainActivity().clearScore();
        //清理
    	for (int y = 0; y < 4; y++) {
			for(int x = 0; x < 4; x++){
				cardsMap[x][y].setNum(0);
			}			
		}
		//随机添加两个数
    	addRandomNum();
    	addRandomNum();
    }
	//添加随机数
    private void addRandomNum(){
		//把这个point清空，每次调用添加随机数时就清空之前的emptyPoints
		emptyPoints.clear();
		//对所有的位置进行遍历：即为每个卡片加上了可以控制的Point
    	for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {
				if(cardsMap[x][y].getNum()<=0){
					emptyPoints.add(new Point(x,y));
				}
			}
		}
    	Point p = emptyPoints.remove((int)(Math.random()*emptyPoints.size()));//从集合中随机选出一个空位置
    	cardsMap[p.x][p.y].setNum(Math.random()>0.1?2:4);
    	cardsMap[p.x][p.y].setBGColor(cardsMap[p.x][p.y].getNum());//设置卡片的值
    }
    //滑动
    private void swipeLeft(){
    	boolean merge = false;//是否合并
    	for (int y = 0; y < 4; y++) {//y轴
			for(int x = 0; x < 4; x++){
				for(int x1 = x+1; x1 < 4; x1++){ //向右遍历
					//当前位置上的值不为0
					if(cardsMap[x1][y].getNum()>0){//不是空的
						//当前卡片左边的卡片为空，则将当前卡片的值传到左边
						if(cardsMap[x][y].getNum()<=0){//如果当前位置的值为空
							cardsMap[x][y].setNum(cardsMap[x1][y].getNum());
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x1][y].setNum(0);
							cardsMap[x1][y].setBGColor(cardsMap[x1][y].getNum());
							x--;//避免放完之后相邻位置上的数字相同，所以再遍历一次
							merge = true;
						//左边卡片的值不为空且与当前值当等
						}else if(cardsMap[x][y].equals(cardsMap[x1][y])){//如果两个值相同就合并
							cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x1][y].setNum(0);
							cardsMap[x1][y].setBGColor(cardsMap[x1][y].getNum());
					        MainActivity.getMainActivity().addScore(cardsMap[x][y].getNum());
					        merge = true;
						}
						break;
					}
				}
			}			
		}
    	
    	if(merge){
    		addRandomNum();
    		checkComplete();
    	}
    }
    
    private void swipeRight(){
    	
    	boolean merge = false;
    	
    	for (int y = 0; y < 4; y++) {
			for(int x = 3; x >= 0; x--){
				
				for(int x1 = x-1; x1 >= 0; x1--){
					if(cardsMap[x1][y].getNum()>0){
						//左边的卡片为空，则将当前卡片的值传到左边
						if(cardsMap[x][y].getNum()<=0){
							cardsMap[x][y].setNum(cardsMap[x1][y].getNum());
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x1][y].setNum(0);
							cardsMap[x1][y].setBGColor(cardsMap[x1][y].getNum());
							x++;
							merge = true;
						//左边卡片的值不为空且与当前值当等
						}else if(cardsMap[x][y].equals(cardsMap[x1][y])){
							cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x1][y].setNum(0);
							cardsMap[x1][y].setBGColor(cardsMap[x1][y].getNum());
							
							MainActivity.getMainActivity().addScore(cardsMap[x][y].getNum());
							merge = true;
						}
						break;
					}
				}
			}			
		}
    	if(merge){
    		addRandomNum();
    		checkComplete();
    	}
    }

    private void swipeUp(){
    	boolean merge = false;
    	for (int x = 0; x < 4; x++) {
			for(int y = 0; y < 4; y++){

				for(int y1 = y+1; y1 < 4; y1++){
					if(cardsMap[x][y1].getNum()>0){
						//左边的卡片为空，则将当前卡片的值传到左边
						if(cardsMap[x][y].getNum()<=0){
							cardsMap[x][y].setNum(cardsMap[x][y1].getNum());
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x][y1].setNum(0);
							cardsMap[x][y1].setBGColor(cardsMap[x][y1].getNum());
							y--;
							merge = true;
						//左边卡片的值不为空且与当前值当等
						}else if(cardsMap[x][y].equals(cardsMap[x][y1])){
							cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x][y1].setNum(0);
							cardsMap[x][y1].setBGColor(cardsMap[x][y1].getNum());
							
							MainActivity.getMainActivity().addScore(cardsMap[x][y].getNum());
							merge = true;
						}
						break;
					}
				}
			}			
		}
    	if(merge){
    		addRandomNum();
    		checkComplete();
    	}
    }

    private void swipeDown(){
    	boolean merge = false;
    	for (int x = 0; x < 4; x++) {
			for(int y = 3; y >= 0; y--){
				for(int y1 = y-1; y1 >= 0; y1--){
					if(cardsMap[x][y1].getNum()>0){
						//左边的卡片为空，则将当前卡片的值传到左边
						if(cardsMap[x][y].getNum()<=0){
							cardsMap[x][y].setNum(cardsMap[x][y1].getNum());
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x][y1].setNum(0);
							cardsMap[x][y1].setBGColor(cardsMap[x][y1].getNum());
							y++;
							merge = true;
						//左边卡片的值不为空且与当前值当等
						}else if(cardsMap[x][y].equals(cardsMap[x][y1])){
							cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
							cardsMap[x][y].setBGColor(cardsMap[x][y].getNum());
							cardsMap[x][y1].setNum(0);
							cardsMap[x][y1].setBGColor(cardsMap[x][y1].getNum());
							
							MainActivity.getMainActivity().addScore(cardsMap[x][y].getNum());
							merge = true;
						}
						break;
					}
				}
			}			
		}
    	if(merge){
    		addRandomNum();
    		checkComplete();
    	}
    }
	//判断游戏结束
	private void checkComplete(){
		boolean isfull=true;//判断卡片是否铺满的标志变量
		for (int x = 0; x < 4; x++) {
			for (int y = 0; y < 4; y++) {
				if (cardsMap[x][y].getNum()==0
						||(x>0&&cardsMap[x][y].equals(cardsMap[x-1][y]))
						||(x<3&&cardsMap[x][y].equals(cardsMap[x+1][y]))
						||(y>0&&cardsMap[x][y].equals(cardsMap[x][y-1]))
						||(y<3&&cardsMap[x][y].equals(cardsMap[x][y+1]))) {
					isfull=false;
					break;
				}
			}
		}
		if (isfull) {
			AlertDialog.Builder dialog=new AlertDialog.Builder(getContext());
			dialog.setTitle("Game Over！");
			dialog.setMessage("你太菜了！想要再玩一次么？");
			dialog.setCancelable(false);
			dialog.setPositiveButton("重新开始",new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					startGame();
				}
			});
			dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
				}
			});
			dialog.show();
		}
	}
}
