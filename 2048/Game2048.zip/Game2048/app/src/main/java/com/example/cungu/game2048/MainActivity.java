package com.example.cungu.game2048;

import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {
	private TextView tvScore;
	private ImageView music_turnoff;
	private Button restart;
	private GameView gameView;
    private int score = 0;
    private static MainActivity mainActivity = null;
	public MainActivity(){
		mainActivity = this;
	}
    public static MainActivity getMainActivity(){ return mainActivity;  }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvScore = (TextView) findViewById(R.id.tvScore);
        music_turnoff=(ImageView)findViewById(R.id.turn_off_music);
        restart=(Button)findViewById(R.id.restart);
        gameView=(GameView)findViewById(R.id.gameView);
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameView.startGame();
            }
        });
        Intent intent = new Intent(this, MediaService.class);
        //增加StartService，来增加后台播放功能
        startService(intent);
        music_turnoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStop();//音乐暂停
            }
        });
    }
    @Override
    protected void onStop(){
        Intent intent = new Intent(MainActivity.this,MediaService.class);
        stopService(intent);
        super.onStop();

    }
    public void clearScore(){
	    score = 0;
	    showScore();
	}
    public void showScore(){
    	tvScore.setText(score+"");
    }
    public void addScore(int s){
    	score+=s;
    	showScore();
    }
}
